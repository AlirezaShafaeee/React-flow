import { TopicProp } from "../models/models";

export const TopicData:TopicProp[] = [
    {
        topic: 'Instagram-User-Code',
        data : 781 ,
        lag : 781 
    },
    {
        topic: 'Instagram-User',
        data: 7211,
        lag: 245
    },
    {
        topic: 'Instagram-User-Code',
        data: 781,
        lag: 781
    },
    {
        topic: 'Instagram-User-Code',
        data: 781,
        lag: 781
    },
    {
        topic: 'Instagram-User',
        data: 7211,
        lag: 245
    },
    {
        topic: 'Instagram-User-Code',
        data: 781,
        lag: 781
    },
    {
        topic: 'Instagram-User-Code',
        data: 781,
        lag: 781
    },
    {
        topic: 'Instagram-User',
        data: 7211,
        lag: 245
    },
    {
        topic: 'Instagram-User-Code',
        data: 781,
        lag: 781
    },
    {
        topic: 'Instagram-User-Code',
        data: 781,
        lag: 781
    },
    {
        topic: 'Instagram-User',
        data: 7211,
        lag: 245
    },
    {
        topic: 'Instagram-User-Code',
        data: 781,
        lag: 781
    },
    {
        topic: 'Instagram-User-Code',
        data: 781,
        lag: 781
    },
    {
        topic: 'Instagram-User',
        data: 7211,
        lag: 245
    },
    {
        topic: 'Instagram-User-Code',
        data: 781,
        lag: 781
    },
    {
        topic: 'Instagram-User',
        data: 7211,
        lag: 245
    },
    {
        topic: 'Thelethon-Test',
        data: 642,
        lag: 366
    },
    {
        topic: 'Tweeter Test',
        data: 7234,
        lag: 63
    },
    {
        topic: 'Instagram-User-Code',
        data: 781,
        lag: 781
    },
    {
        topic: 'Instagram-User',
        data: 7211,
        lag: 245
    },
    {
        topic: 'Thelethon-Test',
        data: 642,
        lag: 366
    },
    {
        topic: 'Tweeter Test',
        data: 7234,
        lag: 63
    },
    {
        topic: 'Instagram-User-Code',
        data: 781,
        lag: 781
    },
    {
        topic: 'Instagram-User',
        data: 7211,
        lag: 245
    },
    {
        topic: 'Thelethon-Test',
        data: 642,
        lag: 366
    },
    {
        topic: 'Tweeter Test',
        data: 7234,
        lag: 63
    },
    {
        topic: 'Instagram-User-Code',
        data: 781,
        lag: 781
    },
    {
        topic: 'Instagram-User',
        data: 7211,
        lag: 245
    },
    {
        topic: 'Thelethon-Test',
        data: 642,
        lag: 366
    },
    {
        topic: 'Tweeter Test',
        data: 7234,
        lag: 63
    },
    {
        topic: 'Instagram-User-Code',
        data: 781,
        lag: 781
    },
    {
        topic: 'Instagram-User',
        data: 7211,
        lag: 245
    },
    {
        topic: 'Thelethon-Test',
        data: 642,
        lag: 366
    },
    {
        topic: 'Tweeter Test',
        data: 7234,
        lag: 63
    },
]